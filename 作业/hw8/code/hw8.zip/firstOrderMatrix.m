function matrix = firstOrderMatrix(secondOrderMatrix)
% Given a matrix F such that X''=FX, generates a matrix (of double the
% size) A such that Y'=AY solves the reduced first-order system.

% Write me!